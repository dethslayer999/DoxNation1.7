helpMain = """
 Why Are u here Skid """
