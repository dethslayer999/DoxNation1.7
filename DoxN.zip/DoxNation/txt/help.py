helpMain = """
 Why Are u here Skid i thought u know how to hack
guess not. anywas help menu will be up on update 1.7 Yay
fagget."""
