import random

header1 = """

"""

header2 = """

 
"""

header5 = """
 
"""

header6 = """
 
"""

header7 = """
 
"""

header8 = """
     
"""

header9 = """
   __ _ _   _   _        ___           _   _

"""

header11 = """
wat?
"""

header12 = """
 1337 Weed
"""

header13 = """
 yay
"""

header14 = """
    LmFAO
"""

header15 = """
,-
"""

header16 = """
 Yay DoxNation
"""

header17 = """
 We Will Rock U
"""

header18 = """

We All Die SomeDay
"""

def lb_header():
    headers = [header1, header2, header5, header6, header7, header8, header9,
        header11, header12, header13, header14, header15, header16, header17, header18]
    return(random.choice(headers))
